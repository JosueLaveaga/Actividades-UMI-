// Josue De Jesus Laveaga Valenzuela
//Actividad 3: Banco Mexicano/Saldo y Salir

var saldo: Double = 0.0
var primerDepositoRealizado = false

func depositar() {
    print("Ingrese la cantidad a depositar:")
    if let cantidad = Double(readLine() ?? "0"), cantidad > 0 {
        saldo += cantidad
        print("Depósito exitoso. Saldo actual: \(saldo)")
        
        primerDepositoRealizado = true
        
        print("¿Desea realizar otro depósito? (Sí/No)")
        if let respuesta = readLine(), respuesta.lowercased() == "no" {
            preguntarOtraTransaccion()
        } else {
            depositar()
        }
    } else {
        print("Cantidad inválida. Intente de nuevo.")
        depositar()
    }
}

func preguntarOtraTransaccion() {
    print("¿Desea realizar otra transacción? (Sí/No)")
    if let respuesta = readLine(), respuesta.lowercased() == "no" {
        print("Cerrando sesión de la cuenta, vuelva pronto.")
    } else {
        mostrarMenu()
    }
}

func retirar() {
    if !primerDepositoRealizado {
        print("No cuenta con saldo disponible para retirar.")
        print("¿Desea realizar otra transacción? (Sí/No)")
        if let respuesta = readLine(), respuesta.lowercased() == "no" {
            print("Cerrando sesión de la cuenta, vuelva pronto.")
        } else {
            mostrarMenu()
        }
        return
    }
    
    if saldo <= 0 {
        print("No cuenta con saldo suficiente para retirar.")
        mostrarMenu()
        return
    }
    
    print("Ingrese la cantidad a retirar:")
    if let cantidad = Double(readLine() ?? "0"), cantidad > 0 {
        if cantidad <= saldo {
            saldo -= cantidad
            print("Retiro exitoso. Saldo actual: \(saldo)")
        } else {
            print("No cuenta con saldo suficiente para retirar esa cantidad.")
        }
        
        print("¿Desea realizar otro retiro? (Sí/No)")
        if let respuesta = readLine(), respuesta.lowercased() == "no" {
            preguntarOtraTransaccion()
        } else {
            retirar()
        }
    } else {
        print("Cantidad inválida. Intente de nuevo.")
        retirar()
    }
}

func mostrarSaldo() {
    print("Tienes un saldo disponible de: \(saldo) pesos.")
    print("¿Desea realizar otra transacción? (Sí/No)")
    if let respuesta = readLine(), respuesta.lowercased() == "no" {
        print("Cerrando sesión de la cuenta, vuelva pronto.")
    } else {
        mostrarMenu()
    }
}

func mostrarMenu() {
    print("Bienvenido al sistema bancario en línea.")
    print("1. Depósito")
    print("2. Retiro")
    print("3. Saldo")
    print("4. Salir")
    print("Ingrese su opción:")
    
    if let opcion = readLine(), let seleccion = Int(opcion) {
        switch seleccion {
        case 1:
            depositar()
        case 2:
            retirar()
        case 3:
            mostrarSaldo()
        case 4:
            print("Cerrando sesión de la cuenta, vuelva pronto.")
        default:
            print("Opción inválida. Por favor, seleccione una opción válida.")
            mostrarMenu()
        }
    } else {
        print("Opción inválida. Por favor, seleccione una opción válida.")
        mostrarMenu()
    }
}

mostrarMenu()

