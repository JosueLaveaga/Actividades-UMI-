import Foundation

// Definición de la estructura del producto
struct Product {
    var name: String
    var price: Double
    var stock: Int
}

// Función para mostrar los productos
func showProducts(products: [Product]) {
    print("==== Productos disponibles ====")
    for (index, product) in products.enumerated() {
        print("\(index + 1). \(product.name) - Precio: $\(String(format: "%.2f", product.price)) - Stock: \(product.stock)")
    }
}

// Función principal
func main() {
    // Lista de productos
    var products = [
        Product(name: "Joyas", price: 49.99, stock: 10),
        Product(name: "Pantalones", price: 79.99, stock: 8),
        Product(name: "Playeras", price: 29.99, stock: 15),
        Product(name: "Tenis", price: 99.99, stock: 5)
    ]

    var totalAmount = 0.0
    var itemsBought: [String: Int] = [:]

    // Mostrar productos disponibles al principio
    showProducts(products: products)

    // Bucle principal
    while true {
        print("\n==== Menú ====")
        print("1. Comprar artículo")
        print("2. Salir")

        // Solicitar la selección al usuario
        if let choice = readLine(), let option = Int(choice), option >= 1 && option <= 2 {
            if option == 2 {
                // Salir del programa y mostrar el desglose del total de la compra
                if totalAmount > 0 {
                    print("\nDesglose de la compra:")
                    for (product, quantity) in itemsBought {
                        print("\(quantity) \(product) - $\(String(format: "%.2f", products.first { $0.name == product }!.price * Double(quantity)))")
                    }
                    print("\nTotal de la compra: $\(String(format: "%.2f", totalAmount))")
                    print("Gracias por su compra. ¡Hasta luego!")
                } else {
                    print("Gracias por visitar nuestra tienda. ¡Hasta luego!")
                }
                break
            } else {
                // Comprar artículo
                print("\nIngrese el número de artículo a comprar:")
                
                if let articleChoice = readLine(), let articleNumber = Int(articleChoice), articleNumber >= 1 && articleNumber <= products.count {
                    let selectedProduct = products[articleNumber - 1]
                    
                    print("Ingrese la cantidad de \(selectedProduct.name) que desea comprar (Stock disponible: \(selectedProduct.stock)):")
                    
                    if let quantityStr = readLine(), let quantity = Int(quantityStr), quantity > 0 && quantity <= selectedProduct.stock {
                        // Realizar la compra
                        products[articleNumber - 1].stock -= quantity
                        let amount = Double(quantity) * selectedProduct.price
                        totalAmount += amount

                        // Actualizar el desglose de los artículos comprados
                        itemsBought[selectedProduct.name, default: 0] += quantity

                        print("\nUsted ha comprado:")
                        print("Artículo: \(selectedProduct.name)")
                        print("Cantidad: \(quantity)")
                        print("Total parcial: $\(String(format: "%.2f", totalAmount))")

                        // Preguntar si desea seguir comprando
                        print("\n¿Desea seguir comprando? (S para sí / N para no):")
                        if let continueShopping = readLine(), continueShopping.uppercased() == "N" {
                            // Mostrar el desglose y el total de la compra y salir
                            print("\nDesglose de la compra:")
                            for (product, quantity) in itemsBought {
                                print("\(quantity) \(product) - $\(String(format: "%.2f", products.first { $0.name == product }!.price * Double(quantity)))")
                            }
                            print("\nTotal de la compra: $\(String(format: "%.2f", totalAmount))")
                            print("Gracias por su compra. ¡Hasta luego!")
                            break
                        }
                    } else {
                        print("Cantidad inválida o insuficiente stock. Operación cancelada.")
                    }
                } else {
                    print("Número de artículo inválido. Inténtalo de nuevo.")
                }
            }
        } else {
            print("Opción inválida. Inténtalo de nuevo.")
        }
    }
}

// Llamar a la función principal
main()
